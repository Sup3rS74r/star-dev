let currentLang = localStorage.getItem('language') || 'pt';

async function loadLanguage(lang) {
    try {
        const response = await fetch(`lang/${lang}.json`);
        const data = await response.json();
        
        // Atualiza textos normais
        document.querySelectorAll('[data-i18n]').forEach(el => {
            const key = el.getAttribute('data-i18n');
            if (data[key]) el.textContent = data[key];
        });
        
        // Atualiza placeholders
        document.querySelectorAll('[data-i18n-placeholder]').forEach(el => {
            const key = el.getAttribute('data-i18n-placeholder');
            if (data[key]) el.setAttribute('placeholder', data[key]);
        });
        
        // Atualiza options do select
        document.querySelectorAll('select option').forEach(option => {
            const key = option.getAttribute('data-i18n');
            if (key && data[key]) option.textContent = data[key];
        });
        
        currentLang = lang;
        localStorage.setItem('language', lang);
    } catch (error) {
        console.error('Erro ao carregar idioma:', error);
    }
}

// Inicializa com o idioma salvo ou padrão
loadLanguage(currentLang);

// Eventos dos botões de idioma
document.querySelectorAll('.language-switcher button').forEach(btn => {
    btn.addEventListener('click', () => {
        const lang = btn.getAttribute('data-lang');
        if (lang !== currentLang) {
            loadLanguage(lang);
        }
    });
});