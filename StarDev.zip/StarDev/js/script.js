// Menu Mobile
const mobileMenu = document.querySelector('.mobile-menu');
const navUl = document.querySelector('nav ul');

mobileMenu.addEventListener('click', () => {
    navUl.classList.toggle('show');
});

// Fechar menu ao clicar em um link
document.querySelectorAll('nav ul li a').forEach(link => {
    link.addEventListener('click', () => {
        if (window.innerWidth <= 768) {
            navUl.classList.remove('show');
        }
    });
});

// Scroll suave
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function(e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});

// Dark Mode
const darkModeToggle = document.getElementById('dark-mode-toggle');
const currentTheme = localStorage.getItem('theme');

if (currentTheme === 'dark') {
    document.documentElement.setAttribute('data-theme', 'dark');
    darkModeToggle.innerHTML = '<i class="fas fa-sun"></i>';
}

darkModeToggle.addEventListener('click', () => {
    const isDark = document.documentElement.getAttribute('data-theme') === 'dark';
    document.documentElement.setAttribute('data-theme', isDark ? 'light' : 'dark');
    darkModeToggle.innerHTML = isDark ? '<i class="fas fa-moon"></i>' : '<i class="fas fa-sun"></i>';
    localStorage.setItem('theme', isDark ? 'light' : 'dark');
});

// Formulário WhatsApp
document.getElementById('whatsapp-form').addEventListener('submit', function(e) {
    e.preventDefault();
    
    const nome = encodeURIComponent(this.nome.value);
    const telefone = encodeURIComponent(this.telefone.value);
    const assunto = encodeURIComponent(this.assunto.options[this.assunto.selectedIndex].text);
    const mensagem = encodeURIComponent(this.mensagem.value);
    
    const texto = `Saudações StarDev! Chamo-me ${nome}, este é o meu WhatsApp: ${telefone} .  \nAssunto: ${assunto}. \nMensagem: ${mensagem}`;
    const url = `https://wa.me/945565157?text=${texto}`;
    
    window.open(url, '_blank');
    this.reset();
    
    const btn = this.querySelector('button');
    const originalText = btn.textContent;
    btn.textContent = '✓ Mensagem enviada!';
    btn.disabled = true;
    
    setTimeout(() => {
        btn.textContent = originalText;
        btn.disabled = false;
    }, 3000);
});

// Back to Top
const backToTopBtn = document.getElementById('back-to-top');
window.addEventListener('scroll', () => {
    backToTopBtn.style.opacity = window.pageYOffset > 300 ? '1' : '0';
});

backToTopBtn.addEventListener('click', () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Ano atual no footer
document.getElementById('current-year').textContent = new Date().getFullYear();