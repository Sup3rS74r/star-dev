// Animação ao rolar
window.addEventListener('scroll', reveal);

function reveal() {
    const reveals = document.querySelectorAll('.service-card, .portfolio-item, .about-content, .contact-form');
    const windowHeight = window.innerHeight;
    const revealPoint = 150;

    reveals.forEach(element => {
        const elementTop = element.getBoundingClientRect().top;
        if (elementTop < windowHeight - revealPoint) {
            element.classList.add('active');
        }
    });
}

// Inicializa animações
document.addEventListener('DOMContentLoaded', () => {
    // Animação inicial do hero
    document.querySelector('.hero h1').style.opacity = '1';
    document.querySelector('.hero-subtitle').style.opacity = '1';
    
    // Força a verificação inicial
    reveal();
    
    // Adiciona classe loaded para transições suaves após o carregamento
    setTimeout(() => {
        document.body.classList.add('loaded');
    }, 500);
});